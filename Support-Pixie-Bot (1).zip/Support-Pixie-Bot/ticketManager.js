// 🎫 Adorable Ticket Management System
const fs = require('fs');
const path = require('path');

class TicketManager {
  constructor() {
    this.ticketsPath = path.join(__dirname, 'tickets_data.json');
    this.loadTickets();
  }

  loadTickets() {
    try {
      if (fs.existsSync(this.ticketsPath)) {
        const data = fs.readFileSync(this.ticketsPath, 'utf8');
        this.tickets = JSON.parse(data);
      } else {
        this.tickets = {};
        this.saveTickets();
      }
    } catch (error) {
      console.error('💔 Error loading tickets:', error);
      this.tickets = {};
    }
  }

  saveTickets() {
    try {
      fs.writeFileSync(this.ticketsPath, JSON.stringify(this.tickets, null, 2));
    } catch (error) {
      console.error('💔 Error saving tickets:', error);
    }
  }

  // 🎫 Create new ticket
  createTicket(channelId, userId, username, reason = null) {
    const ticketData = {
      id: channelId,
      creator: userId,
      creatorUsername: username,
      reason: reason,
      status: 'open',
      priority: 'normal',
      claimedBy: null,
      claimedByUsername: null,
      createdAt: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      messages: [],
      notes: [],
      participants: [userId]
    };

    this.tickets[channelId] = ticketData;
    this.saveTickets();
    return ticketData;
  }

  // 🔍 Get ticket
  getTicket(channelId) {
    return this.tickets[channelId] || null;
  }

  // 🏷️ Claim ticket
  claimTicket(channelId, userId, username) {
    if (this.tickets[channelId]) {
      this.tickets[channelId].claimedBy = userId;
      this.tickets[channelId].claimedByUsername = username;
      this.tickets[channelId].lastActivity = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // 🏷️ Unclaim ticket
  unclaimTicket(channelId) {
    if (this.tickets[channelId]) {
      this.tickets[channelId].claimedBy = null;
      this.tickets[channelId].claimedByUsername = null;
      this.tickets[channelId].lastActivity = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // ⚡ Set priority
  setPriority(channelId, priority) {
    if (this.tickets[channelId]) {
      this.tickets[channelId].priority = priority;
      this.tickets[channelId].lastActivity = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // 📝 Add note
  addNote(channelId, staffId, staffUsername, note) {
    if (this.tickets[channelId]) {
      this.tickets[channelId].notes.push({
        staffId,
        staffUsername,
        note,
        timestamp: new Date().toISOString()
      });
      this.tickets[channelId].lastActivity = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // ➕ Add participant
  addParticipant(channelId, userId) {
    if (this.tickets[channelId] && !this.tickets[channelId].participants.includes(userId)) {
      this.tickets[channelId].participants.push(userId);
      this.tickets[channelId].lastActivity = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // ➖ Remove participant
  removeParticipant(channelId, userId) {
    if (this.tickets[channelId]) {
      this.tickets[channelId].participants = this.tickets[channelId].participants.filter(id => id !== userId);
      this.tickets[channelId].lastActivity = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // 💌 Close ticket
  closeTicket(channelId, closedBy, closedByUsername, reason = null) {
    if (this.tickets[channelId]) {
      this.tickets[channelId].status = 'closed';
      this.tickets[channelId].closedBy = closedBy;
      this.tickets[channelId].closedByUsername = closedByUsername;
      this.tickets[channelId].closeReason = reason;
      this.tickets[channelId].closedAt = new Date().toISOString();
      this.saveTickets();
      return true;
    }
    return false;
  }

  // 🗑️ Delete ticket
  deleteTicket(channelId) {
    if (this.tickets[channelId]) {
      delete this.tickets[channelId];
      this.saveTickets();
      return true;
    }
    return false;
  }

  // 📊 Get statistics
  getStats() {
    const tickets = Object.values(this.tickets);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

    return {
      total: tickets.length,
      open: tickets.filter(t => t.status === 'open').length,
      closed: tickets.filter(t => t.status === 'closed').length,
      today: tickets.filter(t => new Date(t.createdAt) >= today).length,
      thisWeek: tickets.filter(t => new Date(t.createdAt) >= weekAgo).length,
      thisMonth: tickets.filter(t => new Date(t.createdAt) >= monthAgo).length,
      claimed: tickets.filter(t => t.claimedBy).length,
      priorities: {
        critical: tickets.filter(t => t.priority === 'critical').length,
        high: tickets.filter(t => t.priority === 'high').length,
        normal: tickets.filter(t => t.priority === 'normal').length,
        low: tickets.filter(t => t.priority === 'low').length
      }
    };
  }

  // 👤 Get user tickets
  getUserTickets(userId) {
    return Object.values(this.tickets).filter(ticket => 
      ticket.creator === userId && ticket.status === 'open'
    );
  }

  // 📜 Generate transcript
  generateTranscript(channelId) {
    const ticket = this.tickets[channelId];
    if (!ticket) return null;

    const transcript = {
      ticketId: channelId,
      creator: ticket.creatorUsername,
      createdAt: ticket.createdAt,
      closedAt: ticket.closedAt || 'Still Open',
      status: ticket.status,
      priority: ticket.priority,
      claimedBy: ticket.claimedByUsername || 'Unclaimed',
      reason: ticket.reason || 'No reason provided',
      closeReason: ticket.closeReason || 'N/A',
      participants: ticket.participants.length,
      notes: ticket.notes
    };

    return transcript;
  }
}

module.exports = TicketManager;
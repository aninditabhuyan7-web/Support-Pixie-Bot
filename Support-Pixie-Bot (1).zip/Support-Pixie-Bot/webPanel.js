// 🌸 Support Pixie Bot - Web Configuration Panel 💖
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const path = require('path');
const fs = require('fs');

const CuteConfig = require('./config');
const TicketManager = require('./ticketManager');

class WebPanel {
  constructor(client) {
    this.app = express();
    this.client = client;
    this.config = new CuteConfig();
    this.ticketManager = new TicketManager();
    this.port = 5000; // Use port 5000 as required
    
    this.setupMiddleware();
    this.setupAuth();
    this.setupRoutes();
  }

  setupMiddleware() {
    // 🎨 View engine setup
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'views'));
    
    // 📁 Static files
    this.app.use('/static', express.static(path.join(__dirname, 'public')));
    
    // 📝 Body parsing
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // 🍪 Session management
    this.app.use(session({
      secret: process.env.SESSION_SECRET || 'support-pixie-session-secret',
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false, maxAge: 86400000 } // 24 hours
    }));
    
    // 🔐 Passport initialization
    this.app.use(passport.initialize());
    this.app.use(passport.session());
  }

  setupAuth() {
    // 🔐 Discord OAuth Strategy
    passport.use(new DiscordStrategy({
      clientID: process.env.CLIENT_ID,
      clientSecret: process.env.CLIENT_SECRET || 'your-client-secret',
      callbackURL: '/auth/discord/callback',
      scope: ['identify', 'guilds']
    }, (accessToken, refreshToken, profile, done) => {
      return done(null, profile);
    }));

    passport.serializeUser((user, done) => {
      done(null, user);
    });

    passport.deserializeUser((user, done) => {
      done(null, user);
    });
  }

  setupRoutes() {
    // 🏠 Home page
    this.app.get('/', (req, res) => {
      if (!req.user) {
        return res.render('login', { 
          title: '🌸 Support Pixie Bot - Login',
          botName: 'Support Pixie Bot'
        });
      }
      
      // Get user's guilds that have the bot
      const userGuilds = req.user.guilds?.filter(guild => {
        return this.client.guilds.cache.has(guild.id) && 
               ((guild.permissions & 0x20) === 0x20); // MANAGE_GUILD permission
      }) || [];
      
      res.render('dashboard', { 
        title: '🌸 Support Pixie Dashboard',
        user: req.user,
        guilds: userGuilds,
        stats: this.config.getUnifiedStats(this.ticketManager)
      });
    });

    // 🔐 Authentication routes
    this.app.get('/auth/discord', passport.authenticate('discord'));
    
    this.app.get('/auth/discord/callback', 
      passport.authenticate('discord', { failureRedirect: '/' }),
      (req, res) => {
        res.redirect('/');
      }
    );

    this.app.get('/logout', (req, res) => {
      req.logout(() => {
        res.redirect('/');
      });
    });

    // 🎛️ Configuration routes
    this.app.get('/config/:guildId', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      const guild = this.client.guilds.cache.get(guildId);
      
      if (!guild) {
        return res.status(404).render('error', { 
          title: 'Guild Not Found',
          message: 'Bot is not in this server or server not found.' 
        });
      }

      // Check if user has admin permissions
      if (!this.hasGuildPermission(req.user, guildId)) {
        return res.status(403).render('error', { 
          title: 'Access Denied',
          message: 'You need Manage Server permission to configure this bot.' 
        });
      }

      res.render('config', {
        title: `🎛️ Configure ${guild.name}`,
        guild: guild,
        config: this.config.config,
        channels: guild.channels.cache.filter(c => c.type === 0).map(c => ({ id: c.id, name: c.name })),
        categories: guild.channels.cache.filter(c => c.type === 4).map(c => ({ id: c.id, name: c.name })),
        roles: guild.roles.cache.filter(r => !r.managed && r.name !== '@everyone').map(r => ({ id: r.id, name: r.name, color: r.hexColor }))
      });
    });

    // 💾 Save configuration
    this.app.post('/config/:guildId/save', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      
      if (!this.hasGuildPermission(req.user, guildId)) {
        return res.status(403).json({ success: false, message: 'Access denied' });
      }

      try {
        const updates = req.body;
        
        // Update embed color
        if (updates.embedColor && /^#[0-9A-F]{6}$/i.test(updates.embedColor)) {
          this.config.set('embedColor', updates.embedColor);
        }
        
        // Update welcome message
        if (updates.welcomeMessage) {
          this.config.set('welcomeMessage', updates.welcomeMessage);
        }
        
        // Update ticket limit
        if (updates.ticketLimit && !isNaN(parseInt(updates.ticketLimit))) {
          this.config.set('ticketLimit', parseInt(updates.ticketLimit));
        }
        
        // Update auto close time
        if (updates.autoCloseTime !== undefined) {
          this.config.set('autoCloseTime', parseInt(updates.autoCloseTime) || 0);
        }
        
        // Update staff roles
        if (updates.staffRoles && Array.isArray(updates.staffRoles)) {
          this.config.set('staffRoles', updates.staffRoles);
        }
        
        // Update cute responses
        if (updates.cuteResponses !== undefined) {
          this.config.set('cuteResponses', updates.cuteResponses === 'true');
        }

        res.json({ success: true, message: '💖 Configuration saved successfully!' });
      } catch (error) {
        console.error('Error saving config:', error);
        res.status(500).json({ success: false, message: 'Failed to save configuration' });
      }
    });

    // 📊 Statistics API
    this.app.get('/api/stats/:guildId', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      
      if (!this.hasGuildPermission(req.user, guildId)) {
        return res.status(403).json({ success: false, message: 'Access denied' });
      }

      const stats = this.config.getUnifiedStats(this.ticketManager);
      const guild = this.client.guilds.cache.get(guildId);
      
      res.json({
        success: true,
        stats: stats,
        guildInfo: guild ? {
          name: guild.name,
          memberCount: guild.memberCount,
          channels: guild.channels.cache.size,
          roles: guild.roles.cache.size
        } : null
      });
    });

    // 🎫 Ticket management
    this.app.get('/tickets/:guildId', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      const guild = this.client.guilds.cache.get(guildId);
      
      if (!guild || !this.hasGuildPermission(req.user, guildId)) {
        return res.status(404).render('error', { 
          title: 'Access Denied',
          message: 'Guild not found or access denied.' 
        });
      }

      // Get all tickets for this guild
      const allTickets = Object.values(this.ticketManager.tickets);
      const guildTickets = allTickets.filter(ticket => {
        const channel = guild.channels.cache.get(ticket.id);
        return channel !== undefined;
      });

      res.render('tickets', {
        title: `🎫 Tickets - ${guild.name}`,
        guild: guild,
        tickets: guildTickets,
        stats: this.config.getUnifiedStats(this.ticketManager)
      });
    });

    // 🚫 Blacklist management
    this.app.get('/blacklist/:guildId', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      const guild = this.client.guilds.cache.get(guildId);
      
      if (!guild || !this.hasGuildPermission(req.user, guildId)) {
        return res.status(404).render('error', { 
          title: 'Access Denied',
          message: 'Guild not found or access denied.' 
        });
      }

      res.render('blacklist', {
        title: `🚫 Blacklist - ${guild.name}`,
        guild: guild,
        blacklist: this.config.get('blacklistedUsers') || []
      });
    });

    // Add user to blacklist
    this.app.post('/api/blacklist/:guildId/add', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      
      if (!this.hasGuildPermission(req.user, guildId)) {
        return res.status(403).json({ success: false, message: 'Access denied' });
      }

      try {
        const { userId, reason } = req.body;
        
        if (!userId || !/^\d{17,19}$/.test(userId)) {
          return res.status(400).json({ success: false, message: 'Invalid user ID' });
        }

        const blacklist = this.config.get('blacklistedUsers') || [];
        
        if (blacklist.some(entry => entry.userId === userId)) {
          return res.status(409).json({ success: false, message: 'User already blacklisted' });
        }

        blacklist.push({
          userId: userId,
          reason: reason || 'No reason provided',
          addedAt: new Date().toISOString(),
          addedBy: req.user.id
        });

        this.config.set('blacklistedUsers', blacklist);
        res.json({ success: true, message: 'User added to blacklist successfully' });
      } catch (error) {
        console.error('Error adding to blacklist:', error);
        res.status(500).json({ success: false, message: 'Failed to add user to blacklist' });
      }
    });

    // Remove user from blacklist
    this.app.post('/api/blacklist/:guildId/remove', this.requireAuth, (req, res) => {
      const guildId = req.params.guildId;
      
      if (!this.hasGuildPermission(req.user, guildId)) {
        return res.status(403).json({ success: false, message: 'Access denied' });
      }

      try {
        const { userId } = req.body;
        
        if (!userId) {
          return res.status(400).json({ success: false, message: 'User ID required' });
        }

        const blacklist = this.config.get('blacklistedUsers') || [];
        const newBlacklist = blacklist.filter(entry => entry.userId !== userId);

        if (newBlacklist.length === blacklist.length) {
          return res.status(404).json({ success: false, message: 'User not found in blacklist' });
        }

        this.config.set('blacklistedUsers', newBlacklist);
        res.json({ success: true, message: 'User removed from blacklist successfully' });
      } catch (error) {
        console.error('Error removing from blacklist:', error);
        res.status(500).json({ success: false, message: 'Failed to remove user from blacklist' });
      }
    });

    // 404 handler
    this.app.use((req, res) => {
      res.status(404).render('error', { 
        title: '404 - Page Not Found',
        message: 'The page you are looking for does not exist.' 
      });
    });
  }

  // 🔐 Authentication middleware
  requireAuth = (req, res, next) => {
    if (!req.user) {
      return res.redirect('/');
    }
    next();
  };

  // 👑 Check guild permissions
  hasGuildPermission(user, guildId) {
    if (!user || !user.guilds) return false;
    
    const userGuild = user.guilds.find(g => g.id === guildId);
    if (!userGuild) return false;
    
    // Check for Manage Guild permission (0x20)
    return (userGuild.permissions & 0x20) === 0x20;
  }

  // 🚀 Start the web server
  start() {
    this.app.listen(this.port, '0.0.0.0', () => {
      console.log(`🌸 Support Pixie Web Panel is running on http://0.0.0.0:${this.port}! 💖`);
    });
  }
}

module.exports = WebPanel;
// deploy-commands.js
const { REST, Routes, SlashCommandBuilder } = require('discord.js');
require('dotenv').config();

const commands = [
  // 🎫 SETUP COMMANDS (Admin Only)
  new SlashCommandBuilder()
    .setName('setup-panel')
    .setDescription('🌸 Create a super cute ticket panel with categories!')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Where to place the magical ticket panel')
        .addChannelTypes(0) // Text channel
        .setRequired(false))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('setup-category')
    .setDescription('📁 Setup ticket categories for different types of help')
    .addStringOption(option =>
      option.setName('name')
        .setDescription('Category name (e.g., "General Support")')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('emoji')
        .setDescription('Cute emoji for this category (e.g., 💖)')
        .setRequired(true))
    .addChannelOption(option =>
      option.setName('category')
        .setDescription('Discord category channel')
        .addChannelTypes(4) // Category channel
        .setRequired(false))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('setup-staff')
    .setDescription('👑 Set staff roles who can help with tickets')
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Staff role that can manage tickets')
        .setRequired(true))
    .toJSON(),

  // 🎟️ TICKET MANAGEMENT (User Commands)
  new SlashCommandBuilder()
    .setName('new')
    .setDescription('✨ Create a new ticket for help and support!')
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Tell us why you need help (optional)')
        .setRequired(false))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('close')
    .setDescription('💌 Close the current ticket')
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Why are you closing this ticket?')
        .setRequired(false))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('add')
    .setDescription('➕ Add someone cute to this ticket!')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to add to the ticket')
        .setRequired(true))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('remove')
    .setDescription('➖ Remove someone from this ticket')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to remove from the ticket')
        .setRequired(true))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('rename')
    .setDescription('✏️ Give this ticket a new cute name!')
    .addStringOption(option =>
      option.setName('name')
        .setDescription('New adorable name for the ticket')
        .setRequired(true))
    .toJSON(),

  // 🛠️ STAFF COMMANDS
  new SlashCommandBuilder()
    .setName('claim')
    .setDescription('🏷️ Claim this ticket as your responsibility!')
    .toJSON(),

  new SlashCommandBuilder()
    .setName('unclaim')
    .setDescription('🏷️ Release your claim on this ticket')
    .toJSON(),

  new SlashCommandBuilder()
    .setName('priority')
    .setDescription('⚡ Set ticket priority level')
    .addStringOption(option =>
      option.setName('level')
        .setDescription('Priority level')
        .setRequired(true)
        .addChoices(
          { name: '🔥 Critical', value: 'critical' },
          { name: '⚡ High', value: 'high' },
          { name: '📝 Normal', value: 'normal' },
          { name: '💤 Low', value: 'low' }
        ))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('note')
    .setDescription('📝 Add a private staff note to this ticket')
    .addStringOption(option =>
      option.setName('note')
        .setDescription('Private note visible only to staff')
        .setRequired(true))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('transcript')
    .setDescription('📜 Generate a cute transcript of this ticket')
    .toJSON(),

  new SlashCommandBuilder()
    .setName('force-close')
    .setDescription('🔒 Force close any ticket (Staff only)')
    .addChannelOption(option =>
      option.setName('ticket')
        .setDescription('Ticket channel to force close')
        .addChannelTypes(0)
        .setRequired(false))
    .toJSON(),

  // 👑 ADMIN COMMANDS
  new SlashCommandBuilder()
    .setName('stats')
    .setDescription('📊 View adorable ticket statistics!')
    .addStringOption(option =>
      option.setName('period')
        .setDescription('Time period for stats')
        .setRequired(false)
        .addChoices(
          { name: '📅 Today', value: 'today' },
          { name: '📅 This Week', value: 'week' },
          { name: '📅 This Month', value: 'month' },
          { name: '📅 All Time', value: 'all' }
        ))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('🚫 Manage the naughty list (prevent ticket creation)')
    .addStringOption(option =>
      option.setName('action')
        .setDescription('Add or remove from blacklist')
        .setRequired(true)
        .addChoices(
          { name: '➕ Add to naughty list', value: 'add' },
          { name: '➖ Remove from naughty list', value: 'remove' }
        ))
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to add/remove from blacklist')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Why are they on the naughty list?')
        .setRequired(false))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('config')
    .setDescription('⚙️ Configure bot settings for maximum cuteness!')
    .addStringOption(option =>
      option.setName('setting')
        .setDescription('What setting to configure')
        .setRequired(true)
        .addChoices(
          { name: '🎨 Embed Color', value: 'color' },
          { name: '💬 Welcome Message', value: 'welcome' },
          { name: '⏰ Auto Close Time', value: 'autoclose' },
          { name: '🔢 Ticket Limit', value: 'limit' }
        ))
    .addStringOption(option =>
      option.setName('value')
        .setDescription('New value for the setting')
        .setRequired(true))
    .toJSON(),

  // 💖 GENERAL COMMANDS
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('🆘 Get help with all my cute commands!')
    .addStringOption(option =>
      option.setName('category')
        .setDescription('Specific command category')
        .setRequired(false)
        .addChoices(
          { name: '🎫 Setup Commands', value: 'setup' },
          { name: '🎟️ User Commands', value: 'user' },
          { name: '🛠️ Staff Commands', value: 'staff' },
          { name: '👑 Admin Commands', value: 'admin' }
        ))
    .toJSON(),

  new SlashCommandBuilder()
    .setName('info')
    .setDescription('📋 Get information about the current ticket')
    .toJSON(),

  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('🏓 Check if I\'m awake and ready to help!')
    .toJSON(),
];

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

// Export commands for auto-deployment
module.exports = { commands };

// Manual deployment when run directly
if (require.main === module) {
  (async () => {
    try {
      console.log('✨ Refreshing application (/) commands...');
      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands },
      );
      console.log('💖 Successfully registered commands!');
    } catch (error) {
      console.error(error);
    }
  })();
}
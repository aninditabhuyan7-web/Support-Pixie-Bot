// 💖 Support Pixie Bot - The Cutest Ticket Bot Ever! 🌸
const { 
  Client, 
  GatewayIntentBits, 
  Partials, 
  PermissionsBitField, 
  ChannelType, 
  ButtonBuilder, 
  ActionRowBuilder, 
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder
} = require('discord.js');
require('dotenv').config();

const CuteConfig = require('./config');
const TicketManager = require('./ticketManager');

// 🌟 Initialize our magical systems
const config = new CuteConfig();
const ticketManager = new TicketManager();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds, 
    GatewayIntentBits.GuildMessages, 
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel, Partials.GuildMember]
});

// 🎨 Cute Helper Functions
const cuteEmoji = ['✨', '💖', '🌸', '🦄', '🌈', '💫', '🎀', '🧚‍♀️', '🌺', '💕'];
const getRandomEmoji = () => cuteEmoji[Math.floor(Math.random() * cuteEmoji.length)];

const priorityEmojis = {
  critical: '🔥',
  high: '⚡',
  normal: '📝',
  low: '💤'
};

// 🚀 Bot Ready Event
client.once('ready', () => {
  console.log(`💖 Support Pixie Bot is online as ${client.user.tag}! Ready to spread love and help! 🌸`);
  client.user.setActivity('🎫 Creating magical tickets!', { type: 'WATCHING' });
});

// 🎭 Main Interaction Handler
client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand()) {
    await handleSlashCommand(interaction);
  } else if (interaction.isButton()) {
    await handleButtonInteraction(interaction);
  } else if (interaction.isStringSelectMenu()) {
    await handleSelectMenuInteraction(interaction);
  } else if (interaction.isModalSubmit()) {
    await handleModalSubmit(interaction);
  }
});

// 🎪 Slash Command Handler
async function handleSlashCommand(interaction) {
  const { commandName } = interaction;
  
  try {
    switch (commandName) {
      // 🎫 SETUP COMMANDS
      case 'setup-panel':
        await handleSetupPanel(interaction);
        break;
      case 'setup-category':
        await handleSetupCategory(interaction);
        break;
      case 'setup-staff':
        await handleSetupStaff(interaction);
        break;
        
      // 🎟️ USER COMMANDS
      case 'new':
        await handleNewTicket(interaction);
        break;
      case 'close':
        await handleCloseTicket(interaction);
        break;
      case 'add':
        await handleAddUser(interaction);
        break;
      case 'remove':
        await handleRemoveUser(interaction);
        break;
      case 'rename':
        await handleRenameTicket(interaction);
        break;
        
      // 🛠️ STAFF COMMANDS
      case 'claim':
        await handleClaimTicket(interaction);
        break;
      case 'unclaim':
        await handleUnclaimTicket(interaction);
        break;
      case 'priority':
        await handleSetPriority(interaction);
        break;
      case 'note':
        await handleAddNote(interaction);
        break;
      case 'transcript':
        await handleTranscript(interaction);
        break;
      case 'force-close':
        await handleForceClose(interaction);
        break;
        
      // 👑 ADMIN COMMANDS
      case 'stats':
        await handleStats(interaction);
        break;
      case 'blacklist':
        await handleBlacklist(interaction);
        break;
      case 'config':
        await handleConfig(interaction);
        break;
        
      // 💖 GENERAL COMMANDS
      case 'help':
        await handleHelp(interaction);
        break;
      case 'info':
        await handleTicketInfo(interaction);
        break;
      case 'ping':
        await handlePing(interaction);
        break;
        
      default:
        await interaction.reply({ 
          content: `${getRandomEmoji()} Oops! I don't know that command yet! Try \`/help\` to see what I can do! 💖`, 
          ephemeral: true 
        });
    }
  } catch (error) {
    console.error('💔 Command error:', error);
    const errorEmbed = config.createEmbed(
      '💔 Oopsie! Something went wrong!',
      `I encountered a little hiccup: \`${error.message}\`\nDon't worry, I'm still here to help! ${getRandomEmoji()}`,
      '#FF6B6B'
    );
    
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
    } else {
      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  }
}

// 🎫 SETUP COMMANDS
async function handleSetupPanel(interaction) {
  if (!config.isAdmin(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Sorry sweetie, only admins can set up the magical ticket panel! Ask a server admin for help! 💖', 
      ephemeral: true 
    });
  }

  const channel = interaction.options.getChannel('channel') || interaction.channel;
  
  const embed = config.createEmbed(
    '🎫 Support Pixie Ticket System 🌸',
    '💖 Need help? Create a ticket and our friendly staff will assist you!\n\n🌟 **What can we help with?**\n• General questions and support\n• Bug reports and issues\n• Suggestions and feedback\n• Account problems\n• And much more!\n\n✨ Click the button below to create your magical support ticket!'
  );
  
  const button = new ButtonBuilder()
    .setCustomId('create_ticket_panel')
    .setLabel('✨ Create Support Ticket ✨')
    .setStyle(ButtonStyle.Primary)
    .setEmoji('🎫');
  
  const row = new ActionRowBuilder().addComponents(button);
  
  await channel.send({ embeds: [embed], components: [row] });
  
  await interaction.reply({ 
    content: `${getRandomEmoji()} Perfect! I've created a super cute ticket panel in ${channel}! Users can now create tickets with a single click! 💖`, 
    ephemeral: true 
  });
}

async function handleSetupCategory(interaction) {
  if (!config.isAdmin(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only admins can configure ticket categories! 💖', 
      ephemeral: true 
    });
  }

  const name = interaction.options.getString('name');
  const emoji = interaction.options.getString('emoji');
  const category = interaction.options.getChannel('category');
  
  const categories = config.get('ticketCategories');
  categories.push({
    name,
    emoji,
    categoryId: category?.id || null
  });
  
  config.set('ticketCategories', categories);
  
  const embed = config.createEmbed(
    '📁 Category Added Successfully!',
    `${getRandomEmoji()} Added new ticket category:\n**${emoji} ${name}**\n${category ? `Category: ${category}` : 'No Discord category set'}`
  );
  
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleSetupStaff(interaction) {
  if (!config.isAdmin(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only admins can set up staff roles! 💖', 
      ephemeral: true 
    });
  }

  const role = interaction.options.getRole('role');
  const staffRoles = config.get('staffRoles');
  
  if (!staffRoles.includes(role.id)) {
    staffRoles.push(role.id);
    config.set('staffRoles', staffRoles);
    
    const embed = config.createEmbed(
      '👑 Staff Role Added!',
      `${getRandomEmoji()} Successfully added ${role} as a staff role!\nThey can now help manage tickets! 💖`
    );
    
    await interaction.reply({ embeds: [embed], ephemeral: true });
  } else {
    await interaction.reply({ 
      content: `${getRandomEmoji()} That role is already set up as staff! They're already part of our amazing team! 💖`, 
      ephemeral: true 
    });
  }
}

// 🎟️ USER COMMANDS
async function handleNewTicket(interaction) {
  if (config.isBlacklisted(interaction.user.id)) {
    return await interaction.reply({ 
      content: '🚫 Sorry sweetie, you\'re currently unable to create tickets. Contact an admin if you think this is a mistake! 💔', 
      ephemeral: true 
    });
  }

  const userTickets = ticketManager.getUserTickets(interaction.user.id);
  const ticketLimit = config.get('ticketLimit');
  
  if (userTickets.length >= ticketLimit) {
    return await interaction.reply({ 
      content: `${getRandomEmoji()} You already have ${userTickets.length} open tickets! Please close some before creating new ones! 💖`, 
      ephemeral: true 
    });
  }

  const reason = interaction.options.getString('reason');
  
  await createTicketChannel(interaction, reason);
}

async function createTicketChannel(interaction, reason = null, category = 'General Support') {
  const guild = interaction.guild;
  const user = interaction.user;
  
  // Create category if it doesn't exist
  let ticketCategory = guild.channels.cache.find(
    c => c.name === '🎟 Support Tickets' && c.type === ChannelType.GuildCategory
  );
  
  if (!ticketCategory) {
    try {
      ticketCategory = await guild.channels.create({
        name: '🎟 Support Tickets',
        type: ChannelType.GuildCategory,
      });
    } catch (error) {
      console.error('Error creating category:', error);
      return await interaction.reply({ 
        content: '💔 Failed to create ticket category. Please contact an admin!', 
        ephemeral: true 
      });
    }
  }

  // Generate unique ticket name
  const ticketCount = Object.keys(ticketManager.tickets).length + 1;
  const ticketName = `ticket-${String(ticketCount).padStart(4, '0')}`;
  
  try {
    // Create ticket channel
    const ticketChannel = await guild.channels.create({
      name: ticketName,
      type: ChannelType.GuildText,
      parent: ticketCategory.id,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionsBitField.Flags.ViewChannel],
        },
        {
          id: user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel, 
            PermissionsBitField.Flags.SendMessages, 
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.AttachFiles
          ],
        },
        {
          id: client.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel, 
            PermissionsBitField.Flags.SendMessages, 
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.ManageChannels
          ],
        },
        // Add staff role permissions
        ...config.get('staffRoles').map(roleId => ({
          id: roleId,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.ManageMessages
          ]
        }))
      ],
    });

    // Create ticket in manager
    ticketManager.createTicket(ticketChannel.id, user.id, user.username, reason);
    config.incrementTicketCount();
    
    // Reply to user
    await interaction.reply({ 
      content: `${getRandomEmoji()} Yay! Your magical support ticket is ready: ${ticketChannel}! 💖`, 
      ephemeral: true 
    });

    // Welcome message with personalized greeting
    const welcomeMsg = config.get('welcomeMessage').replace('{user}', user.toString());
    const welcomeEmbed = config.createEmbed(
      `🌸 Welcome to your Support Ticket! ${getRandomEmoji()}`,
      `${welcomeMsg}\n\n**Ticket Information:**\n🎫 **Ticket ID:** \`${ticketName}\`\n👤 **Created by:** ${user}\n📝 **Reason:** ${reason || 'No reason provided'}\n⏰ **Created:** <t:${Math.floor(Date.now() / 1000)}:F>`
    );
    
    // Control buttons
    const controlRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('close_ticket')
        .setLabel('Close Ticket')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🔒'),
      new ButtonBuilder()
        .setCustomId('claim_ticket')
        .setLabel('Claim Ticket')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('🏷️'),
      new ButtonBuilder()
        .setCustomId('add_user_modal')
        .setLabel('Add User')
        .setStyle(ButtonStyle.Success)
        .setEmoji('➕')
    );
    
    await ticketChannel.send({ 
      content: user.toString(),
      embeds: [welcomeEmbed], 
      components: [controlRow] 
    });
    
    // Send staff notification if configured
    const randomMessage = config.getRandomMessage();
    if (randomMessage) {
      setTimeout(async () => {
        await ticketChannel.send(`🤖 ${randomMessage}`);
      }, 2000);
    }
    
  } catch (error) {
    console.error('Error creating ticket channel:', error);
    await interaction.reply({ 
      content: '💔 Failed to create your ticket channel. Please try again or contact an admin!', 
      ephemeral: true 
    });
  }
}

async function handleCloseTicket(interaction) {
  const channel = interaction.channel;
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels, sweetie! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 I couldn\'t find this ticket in my database! It might be corrupted. Contact an admin!', 
      ephemeral: true 
    });
  }

  const reason = interaction.options.getString('reason');
  
  // Only creator or staff can close
  if (ticket.creator !== interaction.user.id && !config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only the ticket creator or staff can close this ticket! 💖', 
      ephemeral: true 
    });
  }

  const embed = config.createEmbed(
    '💌 Ticket Closing Soon!',
    `${getRandomEmoji()} This ticket will be closed in 5 seconds!\n**Closed by:** ${interaction.user}\n**Reason:** ${reason || 'No reason provided'}\n\nThank you for using our support system! 💖`
  );
  
  await interaction.reply({ embeds: [embed] });
  
  // Close ticket in manager
  ticketManager.closeTicket(channel.id, interaction.user.id, interaction.user.username, reason);
  
  setTimeout(async () => {
    try {
      await channel.delete();
    } catch (error) {
      console.error('Error deleting channel:', error);
    }
  }, 5000);
}

async function handleAddUser(interaction) {
  const channel = interaction.channel;
  const user = interaction.options.getUser('user');
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  // Only creator or staff can add users
  if (ticket.creator !== interaction.user.id && !config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only the ticket creator or staff can add users! 💖', 
      ephemeral: true 
    });
  }

  try {
    await channel.permissionOverwrites.create(user, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      AttachFiles: true
    });
    
    ticketManager.addParticipant(channel.id, user.id);
    
    const embed = config.createEmbed(
      '➕ User Added Successfully!',
      `${getRandomEmoji()} ${user} has been added to this ticket!\nWelcome to the conversation! 💖`
    );
    
    await interaction.reply({ embeds: [embed] });
    await channel.send(`🌸 ${user} Welcome to this support ticket! Feel free to join the conversation! 💖`);
    
  } catch (error) {
    console.error('Error adding user:', error);
    await interaction.reply({ 
      content: '💔 Failed to add user to ticket. They might already have access!', 
      ephemeral: true 
    });
  }
}

async function handleRemoveUser(interaction) {
  const channel = interaction.channel;
  const user = interaction.options.getUser('user');
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  // Only staff can remove users (for safety)
  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can remove users from tickets! 💖', 
      ephemeral: true 
    });
  }

  // Can't remove the ticket creator
  if (ticket.creator === user.id) {
    return await interaction.reply({ 
      content: '🚫 You can\'t remove the ticket creator! They need to close the ticket instead! 💖', 
      ephemeral: true 
    });
  }

  try {
    await channel.permissionOverwrites.delete(user);
    ticketManager.removeParticipant(channel.id, user.id);
    
    const embed = config.createEmbed(
      '➖ User Removed',
      `${getRandomEmoji()} ${user} has been removed from this ticket by ${interaction.user}! 👋`
    );
    
    await interaction.reply({ embeds: [embed] });
    
  } catch (error) {
    console.error('Error removing user:', error);
    await interaction.reply({ 
      content: '💔 Failed to remove user from ticket!', 
      ephemeral: true 
    });
  }
}

async function handleRenameTicket(interaction) {
  const channel = interaction.channel;
  const newName = interaction.options.getString('name');
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can rename tickets! 💖', 
      ephemeral: true 
    });
  }

  try {
    const sanitizedName = `ticket-${newName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
    await channel.setName(sanitizedName);
    
    const embed = config.createEmbed(
      '✏️ Ticket Renamed!',
      `${getRandomEmoji()} Ticket renamed to: **${sanitizedName}** by ${interaction.user}! ✨`
    );
    
    await interaction.reply({ embeds: [embed] });
    
  } catch (error) {
    console.error('Error renaming ticket:', error);
    await interaction.reply({ 
      content: '💔 Failed to rename ticket! The name might be too long or invalid.', 
      ephemeral: true 
    });
  }
}

// 🛠️ STAFF COMMANDS
async function handleClaimTicket(interaction) {
  const channel = interaction.channel;
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can claim tickets! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  if (ticket.claimedBy) {
    return await interaction.reply({ 
      content: `🏷️ This ticket is already claimed by **${ticket.claimedByUsername}**! Use \`/unclaim\` first if you need to take over! 💖`, 
      ephemeral: true 
    });
  }

  ticketManager.claimTicket(channel.id, interaction.user.id, interaction.user.username);
  
  const embed = config.createEmbed(
    '🏷️ Ticket Claimed!',
    `${getRandomEmoji()} ${interaction.user} has claimed this ticket!\nThey'll be your primary point of contact! 💖`
  );
  
  await interaction.reply({ embeds: [embed] });
  
  // Update channel topic
  try {
    await channel.setTopic(`🏷️ Claimed by ${interaction.user.username} | Priority: ${ticket.priority} | Created: ${new Date(ticket.createdAt).toLocaleDateString()}`);
  } catch (error) {
    console.error('Error updating topic:', error);
  }
}

async function handleUnclaimTicket(interaction) {
  const channel = interaction.channel;
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can unclaim tickets! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  if (!ticket.claimedBy) {
    return await interaction.reply({ 
      content: '🏷️ This ticket isn\'t claimed by anyone! Use \`/claim\` to claim it! 💖', 
      ephemeral: true 
    });
  }

  // Only the claimer or admin can unclaim
  if (ticket.claimedBy !== interaction.user.id && !config.isAdmin(interaction.member)) {
    return await interaction.reply({ 
      content: `🚫 Only **${ticket.claimedByUsername}** or an admin can unclaim this ticket! 💖`, 
      ephemeral: true 
    });
  }

  ticketManager.unclaimTicket(channel.id);
  
  const embed = config.createEmbed(
    '🏷️ Ticket Unclaimed',
    `${getRandomEmoji()} This ticket is now available for any staff member to claim! 💖`
  );
  
  await interaction.reply({ embeds: [embed] });
  
  // Update channel topic
  try {
    await channel.setTopic(`🎫 Unclaimed | Priority: ${ticket.priority} | Created: ${new Date(ticket.createdAt).toLocaleDateString()}`);
  } catch (error) {
    console.error('Error updating topic:', error);
  }
}

async function handleSetPriority(interaction) {
  const channel = interaction.channel;
  const priority = interaction.options.getString('level');
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can set ticket priority! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  ticketManager.setPriority(channel.id, priority);
  
  const priorityColors = {
    critical: '#FF0000',
    high: '#FF8C00',
    normal: '#00FF00',
    low: '#808080'
  };
  
  const embed = config.createEmbed(
    '⚡ Priority Updated!',
    `${getRandomEmoji()} Ticket priority set to **${priorityEmojis[priority]} ${priority.toUpperCase()}** by ${interaction.user}!`,
    priorityColors[priority]
  );
  
  await interaction.reply({ embeds: [embed] });
  
  // Update channel topic
  try {
    const claimedText = ticket.claimedBy ? `🏷️ Claimed by ${ticket.claimedByUsername}` : '🎫 Unclaimed';
    await channel.setTopic(`${claimedText} | Priority: ${priority} | Created: ${new Date(ticket.createdAt).toLocaleDateString()}`);
  } catch (error) {
    console.error('Error updating topic:', error);
  }
}

async function handleAddNote(interaction) {
  const channel = interaction.channel;
  const note = interaction.options.getString('note');
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can add notes! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  ticketManager.addNote(channel.id, interaction.user.id, interaction.user.username, note);
  
  const embed = config.createEmbed(
    '📝 Staff Note Added',
    `**Note by ${interaction.user.username}:**\n${note}\n\n*This note is only visible to staff members.*`,
    '#FFA500'
  );
  
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

// 👑 ADMIN COMMANDS
async function handleStats(interaction) {
  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can view statistics! 💖', 
      ephemeral: true 
    });
  }

  const stats = config.getUnifiedStats(ticketManager);
  const period = interaction.options.getString('period') || 'all';
  
  let statsText = '';
  let title = '📊 Adorable Ticket Statistics! 💖';
  
  switch (period) {
    case 'today':
      title = '📅 Today\'s Statistics';
      statsText = `**Tickets Created Today:** ${stats.today}`;
      break;
    case 'week':
      title = '📅 This Week\'s Statistics';
      statsText = `**Tickets This Week:** ${stats.thisWeek}`;
      break;
    case 'month':
      title = '📅 This Month\'s Statistics';
      statsText = `**Tickets This Month:** ${stats.thisMonth}`;
      break;
    default:
      statsText = `**📊 Total Statistics:**
🎫 **Total Tickets:** ${stats.total}
✅ **Open Tickets:** ${stats.open}
✅ **Closed Tickets:** ${stats.closed}
🏷️ **Claimed Tickets:** ${stats.claimed}

**📅 Recent Activity:**
📅 **Today:** ${stats.today}
📅 **This Week:** ${stats.thisWeek}  
📅 **This Month:** ${stats.thisMonth}

**⚡ Priority Breakdown:**
🔥 **Critical:** ${stats.priorities.critical}
⚡ **High:** ${stats.priorities.high}
📝 **Normal:** ${stats.priorities.normal}
💤 **Low:** ${stats.priorities.low}`;
  }
  
  const embed = config.createEmbed(
    title,
    `${getRandomEmoji()} Here are the current statistics!\n\n${statsText}`
  );
  
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleTranscript(interaction) {
  const channel = interaction.channel;
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can generate transcripts! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    let transcript = `📜 TICKET TRANSCRIPT\n`;
    transcript += `═══════════════════════════════════════\n`;
    transcript += `🎫 Ticket ID: ${channel.name}\n`;
    transcript += `👤 Creator: ${ticket.creatorUsername}\n`;
    transcript += `📝 Reason: ${ticket.reason || 'No reason provided'}\n`;
    transcript += `📅 Created: ${new Date(ticket.createdAt).toLocaleString()}\n`;
    transcript += `⚡ Priority: ${ticket.priority}\n`;
    transcript += `🏷️ Claimed by: ${ticket.claimedByUsername || 'Unclaimed'}\n`;
    transcript += `📊 Status: ${ticket.status}\n`;
    transcript += `═══════════════════════════════════════\n\n`;
    
    transcript += `💬 MESSAGES:\n`;
    transcript += `───────────────────────────────────────\n`;
    
    // Use stored messages from ticket manager (more reliable than fetching)
    if (ticket.messages && ticket.messages.length > 0) {
      ticket.messages.forEach(msg => {
        const timestamp = new Date(msg.timestamp).toLocaleString();
        transcript += `[${timestamp}] ${msg.authorTag}: ${msg.content}\n`;
        
        if (msg.embeds && msg.embeds.length > 0) {
          msg.embeds.forEach(embed => {
            transcript += `    📋 Embed: ${embed.title || 'No title'}\n`;
            if (embed.description) {
              transcript += `    📝 ${embed.description.substring(0, 200)}...\n`;
            }
          });
        }
        
        if (msg.attachments && msg.attachments.length > 0) {
          msg.attachments.forEach(attachment => {
            transcript += `    📎 Attachment: ${attachment.name}\n`;
          });
        }
        transcript += `\n`;
      });
    } else {
      transcript += `No messages found in stored data.\n`;
      
      // Fallback: fetch recent messages from Discord
      try {
        const messages = await channel.messages.fetch({ limit: 100 });
        const sortedMessages = messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
        
        sortedMessages.forEach(msg => {
          if (!msg.author.bot || msg.embeds.length > 0) {
            const timestamp = new Date(msg.createdTimestamp).toLocaleString();
            transcript += `[${timestamp}] ${msg.author.tag}: ${msg.content}\n`;
            
            if (msg.embeds.length > 0) {
              msg.embeds.forEach(embed => {
                transcript += `    📋 Embed: ${embed.title || 'No title'}\n`;
                if (embed.description) {
                  transcript += `    📝 ${embed.description.substring(0, 200)}...\n`;
                }
              });
            }
            
            if (msg.attachments.size > 0) {
              msg.attachments.forEach(attachment => {
                transcript += `    📎 Attachment: ${attachment.name}\n`;
              });
            }
            transcript += `\n`;
          }
        });
      } catch (fetchError) {
        transcript += `Failed to fetch messages from Discord API.\n`;
      }
    }
    
    if (ticket.notes.length > 0) {
      transcript += `\n📝 STAFF NOTES:\n`;
      transcript += `───────────────────────────────────────\n`;
      ticket.notes.forEach(note => {
        transcript += `[${new Date(note.timestamp).toLocaleString()}] ${note.staffUsername}: ${note.note}\n`;
      });
    }
    
    transcript += `\n═══════════════════════════════════════\n`;
    transcript += `📊 Generated by Support Pixie Bot 💖\n`;
    transcript += `⏰ Generated at: ${new Date().toLocaleString()}\n`;
    
    // Create file buffer
    const buffer = Buffer.from(transcript, 'utf8');
    const filename = `transcript-${channel.name}-${Date.now()}.txt`;
    
    const embed = config.createEmbed(
      '📜 Transcript Generated!',
      `${getRandomEmoji()} Here's the cute transcript for this ticket!\n**File:** \`${filename}\`\n💖 Perfect for keeping records!`
    );
    
    await interaction.editReply({ 
      embeds: [embed], 
      files: [{ attachment: buffer, name: filename }]
    });
    
  } catch (error) {
    console.error('Error generating transcript:', error);
    await interaction.editReply({ 
      content: '💔 Failed to generate transcript. There might be too many messages!', 
    });
  }
}

async function handleForceClose(interaction) {
  if (!config.isStaff(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only staff can force close tickets! 💖', 
      ephemeral: true 
    });
  }

  const targetChannel = interaction.options.getChannel('ticket') || interaction.channel;
  
  if (!targetChannel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ That\'s not a ticket channel! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(targetChannel.id);
  if (ticket) {
    ticketManager.closeTicket(targetChannel.id, interaction.user.id, interaction.user.username, 'Force closed by staff');
  }
  
  const embed = config.createEmbed(
    '🔒 Ticket Force Closed!',
    `${getRandomEmoji()} **${targetChannel.name}** has been force closed by ${interaction.user}!\nChannel will be deleted in 3 seconds! 💖`
  );
  
  if (targetChannel.id !== interaction.channel.id) {
    await targetChannel.send({ embeds: [embed] });
    await interaction.reply({ 
      content: `✅ Successfully force closed ${targetChannel}!`, 
      ephemeral: true 
    });
  } else {
    await interaction.reply({ embeds: [embed] });
  }
  
  setTimeout(async () => {
    try {
      await targetChannel.delete();
    } catch (error) {
      console.error('Error deleting channel:', error);
    }
  }, 3000);
}

async function handleBlacklist(interaction) {
  if (!config.isAdmin(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only admins can manage the naughty list! 💖', 
      ephemeral: true 
    });
  }

  const action = interaction.options.getString('action');
  const user = interaction.options.getUser('user');
  const reason = interaction.options.getString('reason') || 'No reason provided';
  
  if (action === 'add') {
    if (config.isBlacklisted(user.id)) {
      return await interaction.reply({ 
        content: `${getRandomEmoji()} ${user.tag} is already on the naughty list! 💖`, 
        ephemeral: true 
      });
    }
    
    config.addToBlacklist(user.id, reason);
    
    const embed = config.createEmbed(
      '🚫 Added to Naughty List',
      `${getRandomEmoji()} **${user.tag}** has been added to the blacklist!\n**Reason:** ${reason}\n\nThey won't be able to create tickets anymore! 💔`,
      '#FF6B6B'
    );
    
    await interaction.reply({ embeds: [embed], ephemeral: true });
    
  } else if (action === 'remove') {
    if (!config.isBlacklisted(user.id)) {
      return await interaction.reply({ 
        content: `${getRandomEmoji()} ${user.tag} isn't on the naughty list! 💖`, 
        ephemeral: true 
      });
    }
    
    config.removeFromBlacklist(user.id);
    
    const embed = config.createEmbed(
      '✅ Removed from Naughty List',
      `${getRandomEmoji()} **${user.tag}** has been forgiven and removed from the blacklist!\nThey can create tickets again! 💖`,
      '#90EE90'
    );
    
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
}

async function handleConfig(interaction) {
  if (!config.isAdmin(interaction.member)) {
    return await interaction.reply({ 
      content: '🚫 Only admins can configure my cute settings! 💖', 
      ephemeral: true 
    });
  }

  const setting = interaction.options.getString('setting');
  const value = interaction.options.getString('value');
  
  try {
    switch (setting) {
      case 'color':
        if (!/^#[0-9A-F]{6}$/i.test(value)) {
          return await interaction.reply({ 
            content: '💔 Please provide a valid hex color (e.g., #FF69B4)!', 
            ephemeral: true 
          });
        }
        config.set('embedColor', value);
        break;
        
      case 'welcome':
        config.set('welcomeMessage', value);
        break;
        
      case 'autoclose':
        const hours = parseInt(value);
        if (isNaN(hours) || hours < 0) {
          return await interaction.reply({ 
            content: '💔 Please provide a valid number of hours (0 to disable)!', 
            ephemeral: true 
          });
        }
        config.set('autoCloseTime', hours);
        break;
        
      case 'limit':
        const limit = parseInt(value);
        if (isNaN(limit) || limit < 1 || limit > 10) {
          return await interaction.reply({ 
            content: '💔 Please provide a valid limit between 1 and 10!', 
            ephemeral: true 
          });
        }
        config.set('ticketLimit', limit);
        break;
        
      default:
        return await interaction.reply({ 
          content: '💔 Unknown setting!', 
          ephemeral: true 
        });
    }
    
    const embed = config.createEmbed(
      '⚙️ Configuration Updated!',
      `${getRandomEmoji()} Successfully updated **${setting}** to: \`${value}\`\nI'm getting more adorable! 💖`
    );
    
    await interaction.reply({ embeds: [embed], ephemeral: true });
    
  } catch (error) {
    console.error('Error updating config:', error);
    await interaction.reply({ 
      content: '💔 Failed to update configuration!', 
      ephemeral: true 
    });
  }
}

// 💖 GENERAL COMMANDS
async function handleHelp(interaction) {
  const category = interaction.options.getString('category');
  
  let embed;
  
  if (!category) {
    embed = config.createEmbed(
      '🆘 Support Pixie Bot Help Center! 💖',
      `${getRandomEmoji()} Hi there! I'm your adorable Support Pixie Bot! Here's what I can do:\n\n🎫 **Setup Commands** - Configure the bot\n🎟️ **User Commands** - Create and manage tickets\n🛠️ **Staff Commands** - Help manage tickets\n👑 **Admin Commands** - Server administration\n\nUse \`/help <category>\` to see specific commands!\n\n💖 *I'm here to make support magical!*`
    );
  } else {
    const helpData = {
      setup: {
        title: '🎫 Setup Commands',
        commands: [
          '`/setup-panel` - Create a magical ticket panel',
          '`/setup-category` - Add ticket categories',
          '`/setup-staff` - Set staff roles'
        ]
      },
      user: {
        title: '🎟️ User Commands', 
        commands: [
          '`/new` - Create a new support ticket',
          '`/close` - Close your ticket',
          '`/add` - Add someone to your ticket',
          '`/remove` - Remove someone from ticket',
          '`/rename` - Rename the ticket'
        ]
      },
      staff: {
        title: '🛠️ Staff Commands',
        commands: [
          '`/claim` - Claim a ticket',
          '`/unclaim` - Release ticket claim',
          '`/priority` - Set ticket priority',
          '`/note` - Add private staff note',
          '`/transcript` - Generate transcript',
          '`/force-close` - Force close any ticket'
        ]
      },
      admin: {
        title: '👑 Admin Commands',
        commands: [
          '`/stats` - View ticket statistics',
          '`/blacklist` - Manage user blacklist',
          '`/config` - Configure bot settings'
        ]
      }
    };
    
    const data = helpData[category];
    if (data) {
      embed = config.createEmbed(
        data.title,
        `${getRandomEmoji()} Here are the ${category} commands:\n\n${data.commands.join('\n')}\n\n💖 *Need help with a specific command? Just try using it!*`
      );
    } else {
      embed = config.createEmbed(
        '❓ Unknown Category',
        'Please use: setup, user, staff, or admin'
      );
    }
  }
  
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleTicketInfo(interaction) {
  const channel = interaction.channel;
  
  if (!channel.name.startsWith('ticket-')) {
    return await interaction.reply({ 
      content: '❌ This command can only be used in ticket channels! 💖', 
      ephemeral: true 
    });
  }

  const ticket = ticketManager.getTicket(channel.id);
  if (!ticket) {
    return await interaction.reply({ 
      content: '💔 Ticket not found in database!', 
      ephemeral: true 
    });
  }

  const creator = await client.users.fetch(ticket.creator).catch(() => null);
  const claimer = ticket.claimedBy ? await client.users.fetch(ticket.claimedBy).catch(() => null) : null;
  
  const embed = config.createEmbed(
    '📋 Ticket Information',
    `${getRandomEmoji()} Here's all the info about this ticket!\n\n` +
    `🎫 **Ticket ID:** \`${channel.name}\`\n` +
    `👤 **Creator:** ${creator ? creator.tag : 'Unknown'}\n` +
    `📝 **Reason:** ${ticket.reason || 'No reason provided'}\n` +
    `📅 **Created:** <t:${Math.floor(new Date(ticket.createdAt).getTime() / 1000)}:F>\n` +
    `⚡ **Priority:** ${priorityEmojis[ticket.priority]} ${ticket.priority.toUpperCase()}\n` +
    `🏷️ **Claimed by:** ${claimer ? claimer.tag : 'Unclaimed'}\n` +
    `👥 **Participants:** ${ticket.participants.length}\n` +
    `📝 **Staff Notes:** ${ticket.notes.length}\n` +
    `📊 **Status:** ${ticket.status === 'open' ? '🟢 Open' : '🔴 Closed'}`
  );
  
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handlePing(interaction) {
  const ping = Date.now() - interaction.createdTimestamp;
  
  const embed = config.createEmbed(
    '🏓 Pong! I\'m awake and ready!',
    `${getRandomEmoji()} **Response Time:** \`${ping}ms\`\n**WebSocket Ping:** \`${client.ws.ping}ms\`\n\n💖 I'm here and ready to create magical tickets!`
  );
  
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

// 🎭 Button Interaction Handler
async function handleButtonInteraction(interaction) {
  const { customId } = interaction;
  
  switch (customId) {
    case 'create_ticket_panel':
      await createTicketChannel(interaction);
      break;
    case 'close_ticket':
      await handleCloseTicket(interaction);
      break;
    case 'claim_ticket':
      await handleClaimTicket(interaction);
      break;
    case 'add_user_modal':
      await showAddUserModal(interaction);
      break;
    // Add more button handlers as needed
  }
}

// 🎪 Modal Helper Functions
async function showAddUserModal(interaction) {
  const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
  
  const modal = new ModalBuilder()
    .setCustomId('add_user_modal_submit')
    .setTitle('🌸 Add User to Ticket');

  const userInput = new TextInputBuilder()
    .setCustomId('user_id_input')
    .setLabel('User ID or @mention')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter user ID or @mention the user')
    .setRequired(true);

  const reasonInput = new TextInputBuilder()
    .setCustomId('reason_input')
    .setLabel('Reason for adding (optional)')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Why are you adding this user?')
    .setRequired(false);

  const userRow = new ActionRowBuilder().addComponents(userInput);
  const reasonRow = new ActionRowBuilder().addComponents(reasonInput);
  
  modal.addComponents(userRow, reasonRow);
  
  await interaction.showModal(modal);
}

// 📜 Select Menu Handler
async function handleSelectMenuInteraction(interaction) {
  // Handle category selection for ticket creation
  if (interaction.customId === 'ticket_category_select') {
    const selectedCategory = interaction.values[0];
    await createTicketChannel(interaction, null, selectedCategory);
  }
}

// 🎪 Modal Submit Handler
async function handleModalSubmit(interaction) {
  if (interaction.customId === 'add_user_modal_submit') {
    const channel = interaction.channel;
    const userInput = interaction.fields.getTextInputValue('user_id_input');
    const reason = interaction.fields.getTextInputValue('reason_input') || 'Added via modal';
    
    if (!channel.name.startsWith('ticket-')) {
      return await interaction.reply({ 
        content: '❌ This can only be used in ticket channels! 💖', 
        ephemeral: true 
      });
    }

    // Parse user input (ID or mention)
    let userId = userInput.replace(/[<@!>]/g, ''); // Remove mention formatting
    
    try {
      const user = await interaction.client.users.fetch(userId);
      const ticket = ticketManager.getTicket(channel.id);
      
      if (!ticket) {
        return await interaction.reply({ 
          content: '💔 Ticket not found in database!', 
          ephemeral: true 
        });
      }

      // Only creator or staff can add users
      if (ticket.creator !== interaction.user.id && !config.isStaff(interaction.member)) {
        return await interaction.reply({ 
          content: '🚫 Only the ticket creator or staff can add users! 💖', 
          ephemeral: true 
        });
      }

      await channel.permissionOverwrites.create(user, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true,
        AttachFiles: true
      });
      
      ticketManager.addParticipant(channel.id, user.id);
      
      const embed = config.createEmbed(
        '➕ User Added Successfully!',
        `${getRandomEmoji()} ${user} has been added to this ticket!\n**Reason:** ${reason}\nWelcome to the conversation! 💖`
      );
      
      await interaction.reply({ embeds: [embed] });
      await channel.send(`🌸 ${user} Welcome to this support ticket! Feel free to join the conversation! 💖`);
      
    } catch (error) {
      console.error('Error adding user via modal:', error);
      await interaction.reply({ 
        content: '💔 Failed to add user! Make sure you provided a valid user ID or mention.', 
        ephemeral: true 
      });
    }
  }
}

// 🌸 Start Web Panel
const WebPanel = require('./webPanel');
const webPanel = new WebPanel(client);

// 🚀 Start the magical bot!
client.login(process.env.TOKEN).then(() => {
  // Start web panel after bot is ready
  setTimeout(() => {
    webPanel.start();
  }, 2000);
});

// 🎭 Auto-deploy slash commands on startup  
client.once('ready', async () => {
  try {
    console.log('🎭 Deploying slash commands automatically...');
    const { REST, Routes } = require('discord.js');
    const { commands } = require('./deploy-commands.js');
    
    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log('✨ Slash commands deployed successfully!');
  } catch (error) {
    console.error('💔 Failed to deploy slash commands:', error);
  }
});

// 💔 Error Handling
client.on('error', error => {
  console.error('💔 Discord client error:', error);
});

process.on('unhandledRejection', error => {
  console.error('💔 Unhandled promise rejection:', error);
});

// 📊 Message logging for tickets
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  
  // Log messages in ticket channels
  if (message.channel.name && message.channel.name.startsWith('ticket-')) {
    const ticket = ticketManager.getTicket(message.channel.id);
    if (ticket) {
      // Log the message for transcripts
      ticket.messages.push({
        id: message.id,
        authorId: message.author.id,
        authorTag: message.author.tag,
        content: message.content,
        timestamp: message.createdTimestamp,
        attachments: message.attachments.map(att => ({
          name: att.name,
          url: att.url
        })),
        embeds: message.embeds.map(embed => ({
          title: embed.title,
          description: embed.description
        }))
      });
      
      // Update last activity
      ticket.lastActivity = new Date().toISOString();
      ticketManager.saveTickets();
    }
  }
});

console.log('💖 Support Pixie Bot initialization complete! Starting up with love and magic! 🌸');
// 💖 Support Pixie Bot Configuration System
const fs = require('fs');
const path = require('path');

class CuteConfig {
  constructor() {
    this.configPath = path.join(__dirname, 'server_config.json');
    this.defaultConfig = {
      // 🎨 Appearance Settings
      embedColor: '#FF69B4', // Cute pink!
      welcomeMessage: '💖 Hello {user}! Welcome to your magical support space! Our friendly staff will be with you soon. Don\'t worry, you\'re in safe paws! 🐾',
      
      // 🎫 Ticket Settings
      ticketLimit: 3, // Max tickets per user
      autoCloseTime: 0, // 0 = disabled, time in hours
      ticketCategories: [
        { name: 'General Support', emoji: '💖', categoryId: null },
        { name: 'Bug Reports', emoji: '🐛', categoryId: null },
        { name: 'Suggestions', emoji: '💡', categoryId: null }
      ],
      
      // 👑 Staff Settings
      staffRoles: [], // Array of role IDs
      adminRoles: [], // Array of admin role IDs
      
      // 🚫 Moderation
      blacklistedUsers: [], // Array of {userId, reason, timestamp}
      
      // 📊 Statistics
      stats: {
        totalTickets: 0,
        ticketsToday: 0,
        ticketsThisWeek: 0,
        ticketsThisMonth: 0,
        lastResetDate: new Date().toISOString()
      },
      
      // 🎪 Fun Settings
      cuteResponses: true,
      randomMessages: [
        '✨ Working some magic for you!',
        '🌸 Processing with love and care!',
        '💫 Adding some sparkle to your request!',
        '🦄 Making unicorn magic happen!',
        '🌈 Creating rainbows and solutions!'
      ]
    };
    
    this.loadConfig();
  }

  loadConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const data = fs.readFileSync(this.configPath, 'utf8');
        this.config = { ...this.defaultConfig, ...JSON.parse(data) };
      } else {
        this.config = { ...this.defaultConfig };
        this.saveConfig();
      }
    } catch (error) {
      console.error('💔 Error loading config:', error);
      this.config = { ...this.defaultConfig };
    }
  }

  saveConfig() {
    try {
      fs.writeFileSync(this.configPath, JSON.stringify(this.config, null, 2));
    } catch (error) {
      console.error('💔 Error saving config:', error);
    }
  }

  get(key) {
    return this.config[key];
  }

  set(key, value) {
    this.config[key] = value;
    this.saveConfig();
  }

  // 🎫 Ticket Management
  isStaff(member) {
    return member.permissions.has('ManageChannels') || 
           this.config.staffRoles.some(roleId => member.roles.cache.has(roleId));
  }

  isAdmin(member) {
    return member.permissions.has('Administrator') || 
           this.config.adminRoles.some(roleId => member.roles.cache.has(roleId));
  }

  isBlacklisted(userId) {
    return this.config.blacklistedUsers.some(entry => entry.userId === userId);
  }

  addToBlacklist(userId, reason) {
    this.config.blacklistedUsers.push({
      userId,
      reason,
      timestamp: new Date().toISOString()
    });
    this.saveConfig();
  }

  removeFromBlacklist(userId) {
    this.config.blacklistedUsers = this.config.blacklistedUsers.filter(
      entry => entry.userId !== userId
    );
    this.saveConfig();
  }

  // 📊 Statistics
  incrementTicketCount() {
    this.config.stats.totalTickets++;
    this.config.stats.ticketsToday++;
    this.config.stats.ticketsThisWeek++;
    this.config.stats.ticketsThisMonth++;
    this.saveConfig();
  }

  // Reset daily/weekly/monthly stats if needed
  checkAndResetStats() {
    const now = new Date();
    const lastReset = new Date(this.config.stats.lastResetDate);
    
    // Reset daily stats if it's a new day
    if (now.toDateString() !== lastReset.toDateString()) {
      this.config.stats.ticketsToday = 0;
    }
    
    // Reset weekly stats if it's a new week (Sunday)
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    if (lastReset < weekAgo) {
      this.config.stats.ticketsThisWeek = 0;
    }
    
    // Reset monthly stats if it's a new month
    if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
      this.config.stats.ticketsThisMonth = 0;
    }
    
    this.config.stats.lastResetDate = now.toISOString();
    this.saveConfig();
  }

  // Get unified stats (single source of truth)
  getUnifiedStats(ticketManager) {
    this.checkAndResetStats();
    
    const liveStats = ticketManager.getStats();
    
    return {
      total: this.config.stats.totalTickets,
      open: liveStats.open,
      closed: liveStats.closed,
      claimed: liveStats.claimed,
      today: this.config.stats.ticketsToday,
      thisWeek: this.config.stats.ticketsThisWeek,
      thisMonth: this.config.stats.ticketsThisMonth,
      priorities: liveStats.priorities
    };
  }

  getRandomMessage() {
    if (!this.config.cuteResponses) return null;
    const messages = this.config.randomMessages;
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // 🎨 Embed Creation Helper
  createEmbed(title, description, color = null) {
    return {
      color: parseInt((color || this.config.embedColor).replace('#', ''), 16),
      title: title,
      description: description,
      timestamp: new Date().toISOString(),
      footer: {
        text: '💖 Support Pixie Bot - Spreading love and support!',
        icon_url: null // You can add bot avatar URL here
      }
    };
  }
}

module.exports = CuteConfig;
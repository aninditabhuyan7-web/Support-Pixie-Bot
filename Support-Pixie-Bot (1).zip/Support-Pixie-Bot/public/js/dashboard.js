// 🌸 Support Pixie Dashboard - Frontend JavaScript 💖

// 🍞 Toast notification system
function showToast(type, message, duration = 5000) {
    const toastContainer = getOrCreateToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
    toast.style.cssText = 'margin-bottom: 0.5rem;';
    
    toast.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i>
            <span>${message}</span>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    toastContainer.appendChild(toast);
    
    // Auto-remove after duration
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, duration);
    
    return toast;
}

function getOrCreateToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            max-width: 400px;
        `;
        document.body.appendChild(container);
    }
    return container;
}

// 📊 Statistics updater
class StatsUpdater {
    constructor() {
        this.updateInterval = 30000; // 30 seconds
        this.isRunning = false;
    }
    
    start(guildId = null) {
        if (this.isRunning) return;
        
        this.isRunning = true;
        this.guildId = guildId;
        
        // Update immediately
        this.updateStats();
        
        // Set interval for periodic updates
        this.intervalId = setInterval(() => {
            this.updateStats();
        }, this.updateInterval);
    }
    
    stop() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        this.isRunning = false;
    }
    
    async updateStats() {
        try {
            const endpoint = this.guildId ? 
                `/api/stats/${this.guildId}` : 
                '/api/stats/global';
                
            const response = await fetch(endpoint);
            const data = await response.json();
            
            if (data.success) {
                this.updateStatElements(data.stats);
            }
        } catch (error) {
            console.warn('Failed to update stats:', error);
        }
    }
    
    updateStatElements(stats) {
        const statElements = {
            total: document.querySelector('[data-stat="total"]'),
            open: document.querySelector('[data-stat="open"]'),
            closed: document.querySelector('[data-stat="closed"]'),
            claimed: document.querySelector('[data-stat="claimed"]'),
            today: document.querySelector('[data-stat="today"]'),
            thisWeek: document.querySelector('[data-stat="thisWeek"]'),
            thisMonth: document.querySelector('[data-stat="thisMonth"]')
        };
        
        Object.entries(statElements).forEach(([key, element]) => {
            if (element && stats[key] !== undefined) {
                this.animateNumber(element, parseInt(element.textContent) || 0, stats[key]);
            }
        });
    }
    
    animateNumber(element, from, to) {
        if (from === to) return;
        
        const duration = 1000;
        const steps = 20;
        const stepValue = (to - from) / steps;
        const stepDuration = duration / steps;
        
        let current = from;
        let step = 0;
        
        const timer = setInterval(() => {
            step++;
            current += stepValue;
            
            if (step >= steps) {
                current = to;
                clearInterval(timer);
            }
            
            element.textContent = Math.round(current);
        }, stepDuration);
    }
}

// 🎨 Theme manager
class ThemeManager {
    constructor() {
        this.currentTheme = localStorage.getItem('pixie-theme') || 'cute';
        this.applyTheme();
    }
    
    applyTheme() {
        document.body.setAttribute('data-theme', this.currentTheme);
        
        // Update theme toggle button if exists
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.innerHTML = this.currentTheme === 'cute' ? 
                '<i class="fas fa-moon"></i>' : 
                '<i class="fas fa-heart"></i>';
        }
    }
    
    toggleTheme() {
        this.currentTheme = this.currentTheme === 'cute' ? 'dark' : 'cute';
        localStorage.setItem('pixie-theme', this.currentTheme);
        this.applyTheme();
        
        showToast('success', `Switched to ${this.currentTheme} theme! 💖`);
    }
}

// 🔄 Auto-refresh manager
class AutoRefresh {
    constructor() {
        this.intervals = new Map();
        this.defaultInterval = 30000; // 30 seconds
    }
    
    start(name, callback, interval = this.defaultInterval) {
        this.stop(name); // Stop existing if any
        
        const intervalId = setInterval(callback, interval);
        this.intervals.set(name, intervalId);
        
        console.log(`Started auto-refresh: ${name} (${interval}ms)`);
    }
    
    stop(name) {
        const intervalId = this.intervals.get(name);
        if (intervalId) {
            clearInterval(intervalId);
            this.intervals.delete(name);
            console.log(`Stopped auto-refresh: ${name}`);
        }
    }
    
    stopAll() {
        this.intervals.forEach((intervalId, name) => {
            clearInterval(intervalId);
            console.log(`Stopped auto-refresh: ${name}`);
        });
        this.intervals.clear();
    }
}

// 🌐 Global instances
const statsUpdater = new StatsUpdater();
const themeManager = new ThemeManager();
const autoRefresh = new AutoRefresh();

// 🚀 Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('🌸 Support Pixie Dashboard loaded! 💖');
    
    // Start stats updating if on dashboard
    if (window.location.pathname === '/' || window.location.pathname.includes('/config/')) {
        const guildId = window.location.pathname.match(/\/config\/(\d+)/)?.[1];
        statsUpdater.start(guildId);
    }
    
    // Add theme toggle functionality
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            themeManager.toggleTheme();
        });
    }
    
    // Add smooth scrolling to all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add form validation enhancements
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn && !submitBtn.disabled) {
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                submitBtn.disabled = true;
                
                // Re-enable after 10 seconds as fallback
                setTimeout(() => {
                    if (submitBtn.disabled) {
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    }
                }, 10000);
            }
        });
    });
    
    // Add copy-to-clipboard functionality
    document.querySelectorAll('[data-copy]').forEach(element => {
        element.addEventListener('click', function() {
            const textToCopy = this.getAttribute('data-copy') || this.textContent;
            
            navigator.clipboard.writeText(textToCopy).then(() => {
                showToast('success', 'Copied to clipboard! 📋');
            }).catch(() => {
                showToast('error', 'Failed to copy to clipboard');
            });
        });
    });
});

// 🧹 Cleanup when leaving page
window.addEventListener('beforeunload', function() {
    statsUpdater.stop();
    autoRefresh.stopAll();
});

// 💖 Easter egg
console.log(`
🌸💖🌸💖🌸💖🌸💖🌸💖🌸💖🌸💖🌸
💖     Support Pixie Bot Dashboard     💖
🌸   Made with love and magic! ✨    🌸
💖   https://github.com/support-pixie  💖
🌸💖🌸💖🌸💖🌸💖🌸💖🌸💖🌸💖🌸
`);

// Export for global access
window.PixieDashboard = {
    showToast,
    statsUpdater,
    themeManager,
    autoRefresh
};
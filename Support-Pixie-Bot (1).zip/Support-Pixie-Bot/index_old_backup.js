const { 
  Client, 
  GatewayIntentBits, 
  Partials, 
  PermissionsBitField, 
  ChannelType, 
  ButtonBuilder, 
  ActionRowBuilder, 
  ButtonStyle 
} = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Channel]
});

const TICKET_CATEGORY_NAME = '🎟 Tickets';

client.once('ready', () => {
  console.log(`💖 Cute bot is online as ${client.user.tag}!`);
});

client.on('interactionCreate', async interaction => {
  // Handle slash commands
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'setup-ticket') {
      const button = new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('✨ Create a Ticket ✨')
        .setStyle(ButtonStyle.Primary);

      const row = new ActionRowBuilder().addComponents(button);

      await interaction.reply({
        content: '💖 ✧･ﾟ: *Ticket button created successfully!* ✧･ﾟ:*',
        ephemeral: true,
      });
      
      await interaction.followUp({ 
        content: '🐾 Click the cute button below to open a ticket!', 
        components: [row] 
      });
    }

    if (interaction.commandName === 'close') {
      const channel = interaction.channel;
      if (!channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ This command can only be used in ticket channels.', ephemeral: true });
      }
      await interaction.reply('💌 Goodbye! Ticket is closing…');
      setTimeout(() => channel.delete().catch(console.error), 2000);
    }

    if (interaction.commandName === 'add-user') {
      const channel = interaction.channel;
      const user = interaction.options.getUser('user');
      
      if (!channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ This command can only be used in ticket channels.', ephemeral: true });
      }

      try {
        await channel.permissionOverwrites.create(user, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true,
        });
        await interaction.reply(`✅ Successfully added ${user} to this ticket! 💖`);
      } catch (error) {
        console.error('Error adding user:', error);
        await interaction.reply({ content: '❌ Failed to add user to ticket.', ephemeral: true });
      }
    }

    if (interaction.commandName === 'remove-user') {
      const channel = interaction.channel;
      const user = interaction.options.getUser('user');
      
      if (!channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ This command can only be used in ticket channels.', ephemeral: true });
      }

      try {
        await channel.permissionOverwrites.delete(user);
        await interaction.reply(`✅ Successfully removed ${user} from this ticket! 👋`);
      } catch (error) {
        console.error('Error removing user:', error);
        await interaction.reply({ content: '❌ Failed to remove user from ticket.', ephemeral: true });
      }
    }

    if (interaction.commandName === 'rename-ticket') {
      const channel = interaction.channel;
      const newName = interaction.options.getString('name');
      
      if (!channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ This command can only be used in ticket channels.', ephemeral: true });
      }

      try {
        const sanitizedName = `ticket-${newName.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
        await channel.setName(sanitizedName);
        await interaction.reply(`✅ Ticket renamed to: **${sanitizedName}** ✨`);
      } catch (error) {
        console.error('Error renaming ticket:', error);
        await interaction.reply({ content: '❌ Failed to rename ticket.', ephemeral: true });
      }
    }

    if (interaction.commandName === 'ticket-info') {
      const channel = interaction.channel;
      
      if (!channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ This command can only be used in ticket channels.', ephemeral: true });
      }

      const created = channel.createdAt.toLocaleDateString();
      const memberCount = channel.members.size;
      
      await interaction.reply({
        content: `📋 **Ticket Information**\n🎫 **Name:** ${channel.name}\n📅 **Created:** ${created}\n👥 **Members:** ${memberCount}\n📂 **Category:** ${channel.parent?.name || 'None'}`,
        ephemeral: true
      });
    }

    if (interaction.commandName === 'help') {
      const helpEmbed = {
        color: 0xff69b4,
        title: '🆘 Support Pixie Commands',
        description: 'Here are all the commands you can use:',
        fields: [
          {
            name: '🎫 Ticket Commands',
            value: '`/setup-ticket` - Create a ticket button\n`/close` - Close current ticket\n`/add-user <user>` - Add user to ticket\n`/remove-user <user>` - Remove user from ticket\n`/rename-ticket <name>` - Rename current ticket\n`/ticket-info` - Show ticket information',
            inline: false
          },
          {
            name: '🆘 Other Commands',
            value: '`/help` - Show this help message',
            inline: false
          }
        ],
        footer: { text: '💖 Support Pixie Bot - Always here to help!' }
      };

      await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
    }

    return;
  }

  // Handle button interactions
  if (!interaction.isButton()) return;

  if (interaction.customId === 'create_ticket') {
    const guild = interaction.guild;
    const user = interaction.user;

    // Find or create the ticket category
    let category = guild.channels.cache.find(
      c => c.name === TICKET_CATEGORY_NAME && c.type === ChannelType.GuildCategory
    );
    if (!category) {
      try {
        category = await guild.channels.create({
          name: TICKET_CATEGORY_NAME,
          type: ChannelType.GuildCategory,
        });
      } catch (error) {
        console.error('Error creating category:', error);
        return interaction.reply({ content: '❌ Failed to create ticket category. Please try again later.', ephemeral: true });
      }
    }

    // Sanitize username
    const safeUsername = user.username.toLowerCase().replace(/[^a-z0-9]/g, '');

    // Check if user already has a ticket
    const existing = category.children.cache.find(c => c.name === `ticket-${safeUsername}`);
    if (existing) {
      return interaction.reply({ content: `🐣 You already have a ticket here: ${existing}`, ephemeral: true });
    }

    try {
      // Create ticket channel under category
      const ticketChannel = await guild.channels.create({
        name: `ticket-${safeUsername}`,
        type: ChannelType.GuildText,
        parent: category.id,
        permissionOverwrites: [
          {
            id: guild.roles.everyone,
            deny: [PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory],
          },
          {
            id: client.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory],
          },
        ],
      });

      await interaction.reply({ content: `✨ Yay! Your ticket is ready: ${ticketChannel}`, ephemeral: true });

      // Cute welcome message
      const closeButton = new ButtonBuilder()
        .setCustomId('close_ticket')
        .setLabel('Close Ticket 🛑')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(closeButton);

      await ticketChannel.send({
        content: `💖 Hello ${user}! Our friendly staff will help you soon. Don't worry, you're in safe paws! 🐾`,
      });

      await ticketChannel.send({ content: 'Click the button below when you’re done 🐣', components: [row] });

    } catch (error) {
      console.error('Error creating ticket channel:', error);
      return interaction.reply({ content: '❌ Failed to create ticket channel. Please try again later.', ephemeral: true });
    }
  }

  if (interaction.customId === 'close_ticket') {
    const channel = interaction.channel;

    if (!channel.name.startsWith('ticket-')) {
      return interaction.reply({ content: '❌ This command can only be used in ticket channels.', ephemeral: true });
    }

    await interaction.reply('💌 Goodbye! Ticket is closing…');
    setTimeout(() => channel.delete().catch(console.error), 2000);
  }
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  if (message.content.toLowerCase() === '!setup-ticket') {
    const button = new ButtonBuilder()
      .setCustomId('create_ticket')
      .setLabel('✨ Create a Ticket ✨')
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(button);

    await message.channel.send({ content: '🐾 Click the cute button below to open a ticket!', components: [row] });
  }
});

client.login(process.env.TOKEN);
